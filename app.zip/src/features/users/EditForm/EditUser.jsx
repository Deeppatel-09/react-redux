import React, { useEffect, useState } from 'react'
import { useSelector } from 'react-redux';
import { useNavigate, useParams } from 'react-router-dom';
import CheckBox from '../../../components/CheckBox/CheckBox';
import RadioButton from '../../../components/radioButton/RadionButton';
import SelectButton from '../../../components/select/SelectButton';
import TextField from '../../../components/textField/TextField';

const EditUser = () => {
  const [editFormData, setEditFormData] = useState({FirstName: "",LastName: "",Email : "", Hobby: [], Gender:"", BloodGroup: "",Contact:"",DOB:""});
  const navigate = useNavigate()
  const {id} = useParams()
  const users = useSelector(state=>(state))
  const editUser = users.find(data=>(data.id)===id)

  useEffect(() => {
    if(editUser){
      setEditFormData({FirstName: editUser.FirstName,LastName: editUser.LastName,Email :editUser.Email, Hobby: editUser.Hobby, Gender:editUser.Gender, BloodGroup: editUser.BloodGroup,Contact:editUser.Contact,DOB:editUser.DOB})
    }
  }, [editUser])
  

  let HandleEditChange = (e) => {
    if (e.target.name === 'Hobby') {
      let copy = { ...editFormData }
      if (e.target.checked) {
        copy.Hobby.push(e.target.value)
        console.log(e.target.value)
      } else {
        copy.Hobby = copy.Hobby.filter(el => el !== e.target.value)
      }
      setEditFormData(copy)

    } else {
      setEditFormData(() => ({[e.target.name]: e.target.value}))
    }
  };

  let HandleEdit = (e) => {
    e.preventDefault();
    setEditFormData({FirstName: "",LastName: "",Email : "", Hobby: [], Gender:"", BloodGroup: "",Contact:"",DOB:""})
    navigate("/")
    console.log(editFormData)}

  return (
    <div>
      <TextField label="FirstName" placeholder={"Enter Firstname"} value={editFormData.FirstName} HandleChange={HandleEditChange} /> 
      <TextField label="LastName" placeholder={"Enter Lastname"} value={editFormData.LastName} HandleChange={HandleEditChange} /> 
      <TextField label="Email" placeholder={"Enter Email"} value={editFormData.Email} HandleChange={HandleEditChange} /><br />
      <RadioButton checked={editFormData.Gender} HandleChange={HandleEditChange} /> 
      <SelectButton value={editFormData.BloodGroup} HandleChange={HandleEditChange} />
      <CheckBox checked={editFormData.Hobby} HandleChange={HandleEditChange} />
      <TextField label="Contact" placeholder={"Enter 10 digit contact number"} value={editFormData.Contact} HandleChange={HandleEditChange} />
      <TextField label="DOB" placeholder={"Enter Date Of birth"} value={editFormData.DOB} HandleChange={HandleEditChange} />
      <button type="submit" onClick={HandleEdit}>Edit</button>
    </div>
  )
}

export default EditUser;
