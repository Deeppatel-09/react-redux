import React, { useState } from 'react'
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import CheckBox from '../../../components/CheckBox/CheckBox'
import InputDate from '../../../components/InputDate/InputDate';
import RadioButton from '../../../components/radioButton/RadionButton';
import SelectButton from '../../../components/select/SelectButton';
import TextField from '../../../components/textField/TextField'
import { addUser } from '../../../redux/allActions'
const shortid = require('shortid')

const AddUser = () => {
  const [formData, setFormData] = useState({id: shortid.generate(),FirstName: "",LastName: "",Email : "", Hobby: [], Gender:"", BloodGroup: "",Contact:"",DOB:""});
  const navigate = useNavigate()
  const dispatch = useDispatch();

  let HandleChange = (e) => {
    if (e.target.name === 'Hobby') {
      let copy = { ...formData }
      if (e.target.checked) {
        copy.Hobby.push(e.target.value)
      } else {
        copy.Hobby = copy.Hobby.filter(el => el !== e.target.value)
      }
      setFormData(copy)

    } else {
      setFormData(() => ({...formData,[e.target.name]: e.target.value}))
    }
  };

  let HandleSubmit = (e) => {
    e.preventDefault();
    dispatch(addUser(formData))
    setFormData({FirstName: "",LastName: "",Email : "", Hobby: [], Gender:"", BloodGroup: "",Contact:"",DOB:""})
    navigate("/")
    }

  return (
    <div className='addUser'>
      <TextField label="FirstName" placeholder={"Enter Firstname"} value={formData.FirstName} HandleChange={HandleChange} /> 
      <TextField label="LastName" placeholder={"Enter Lastname"} value={formData.LastName} HandleChange={HandleChange} /> 
      <TextField label="Email" placeholder={"Enter Email"} value={formData.Email} HandleChange={HandleChange} /><br />
      <RadioButton checked={formData.Gender} HandleChange={HandleChange} /> <br /> 
      <SelectButton value={formData.BloodGroup} HandleChange={HandleChange} />
      <CheckBox checked={formData.Hobby} HandleChange={HandleChange} />
      <TextField label="Contact" placeholder={"Enter 10 digit contact number"} value={formData.Contact} HandleChange={HandleChange} />
      {/* <TextField label="DOB" placeholder={"Enter Date Of birth"} value={formData.DOB} HandleChange={HandleChange} /> */}
      <InputDate/>
      <button type="submit" onClick={HandleSubmit}>Submit</button>
    </div>
  )
}

export default AddUser
