import React from 'react'
import EditIcon from '@material-ui/icons/Edit';
import DeleteIcon from '@material-ui/icons/Delete';
import './userList.css'
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { deleteUser } from '../../../redux/allActions'

function UsereList() {
    const dispatch = useDispatch();
    const users = useSelector((state) => {
        return state;
    })
    console.log(users)
  return (
    <>
    <Link to="/add"><button>Add User</button></Link>
    <div className='userLists'>
        {users.length ? users.map((user)=>(
                            <div className='renderCards' key={user.id}>
                                <div className='renderCardContent'>
                                    <h3 className='text-gray-800 font-bold text-lg'>{user.FirstName+" "+user.LastName}</h3>
                                    <div className='renderCardLanguage'>{user.Gender}</div>
                                    <div className='renderCardLanguage'>{user.DOB}</div>
                                    <div className='renderCardLanguage'>{user.Hobby}</div>
                                    <div className='renderCardLanguage'>{user.BloodGroup}</div>
                                </div>
                                <div className='renderCardLanguage'>{user.Contact}</div>
                                <div className='renderCardLanguage'>{user.Email}</div>
                                <div className="renderCardIcons">
                                    <Link to={`/edit/${user.id}`}>
                                        <EditIcon/>
                                    </Link>
                                    <DeleteIcon onClick={()=>dispatch(deleteUser(user.id))}/>
                                </div>
                            </div>
                        )) : 
                            <p className='text-center col-span-2 text-gray-700 font-bold'>No User</p>}
    </div>
    </>
  )
}

export default UsereList