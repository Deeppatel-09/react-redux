import { Route, Routes } from 'react-router-dom';
import './App.css';
import AddUser from './features/users/AddUser/AddUser';
import UsereList from './features/users/UserList/UsereList';
import EditUser from './features/users/EditForm/EditUser';

function App() {
  return (
    <div className="container">
      <h1>CRUD operations using redux</h1>
      <Routes>
        <Route path='/' element={<UsereList/>}/>
        <Route path='/add' element={<AddUser/>}/>
        <Route path='/edit/:id' element={<EditUser/>}/>
      </Routes>
    </div>
  );
}

export default App;
