import * as React from 'react';
import Box from '@mui/material/Box';
import FormControl from '@mui/material/FormControl';
import Input from '@mui/material/Input';
import InputLabel from '@mui/material/InputLabel';

export default function TextField({label,placeholder,value,HandleChange}) {
  return (
    <Box component="form" sx={{'& > :not(style)': { mt: 1 },}} noValidate autoComplete="off" >
        <FormControl fullWidth sx={{ mt: 1 }} variant="standard">
          <InputLabel htmlFor="standard-adornment-amount">{label}</InputLabel>
          <Input id="standard-adornment-amount" placeholder={placeholder} value={value} onChange={HandleChange} name={label}/>
        </FormControl>
    </Box>
  );
}