import React from 'react'
import "./selectButton.css"

const SelectButton = ({value,HandleChange}) => {
  return (
    <div className='SelectButton'>
          <label htmlFor="BloodGroup" className="form-label">BloodGroup: </label>
          <select name="BloodGroup" id="BloodGroup" className="form-select" onChange={HandleChange} value={value} >
            <option>---select---</option>
            <option name="BloodGroup" value="A+">A+</option>
            <option name="BloodGroup" value="B+">B+</option>
            <option name="BloodGroup" value="AB+">AB+</option>
            <option name="BloodGroup" value="O+">O+</option>
          </select>
    </div>
  )
}

export default SelectButton;
