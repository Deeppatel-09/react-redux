import * as React from 'react';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';

export default function RadioButton({HandleChange,checked}) {

  return (
    <FormControl>
      <FormLabel id="demo-controlled-radio-buttons-group">Gender</FormLabel>
      <RadioGroup
        aria-labelledby="demo-controlled-radio-buttons-group"
        name="Gender"
        value={checked}
        onChange={HandleChange}
      >
        <FormControlLabel name="Gender" value="Female" control={<Radio />} checked={checked === "Female"} label="Female" />
        <FormControlLabel name="Gender" value="Male" control={<Radio checked={checked === "Male"}/>}  label="Male" />
      </RadioGroup>
    </FormControl>
  );
}