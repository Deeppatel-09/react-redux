import React from 'react'
import "./inputDate.css";

const InputDate = () => {
  return (
    <div className='Date'>
        <label htmlFor="DOB">DOB: </label>
        <input type="date" name="DOB" id="DOB" />
    </div>
  )
}

export default InputDate
