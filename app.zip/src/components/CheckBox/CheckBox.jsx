import * as React from 'react';
// import Box from '@mui/material/Box';
import FormLabel from '@mui/material/FormLabel';
import FormControl from '@mui/material/FormControl';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
// import FormHelperText from '@mui/material/FormHelperText';
import Checkbox from '@mui/material/Checkbox';

export default function CheckBox({checked,HandleChange}) {

  return (
    <FormControl sx={{ mt: 2 }} component="fieldset" variant="standard">
    <FormLabel component="legend">Hobby</FormLabel>
    <FormGroup>
      <FormControlLabel
        control={
          <Checkbox value="Play" checked={checked.indexOf('Play') !== -1} onChange={HandleChange} name="Hobby" />
        }
        label="Play"
      />
      <FormControlLabel
        control={
          <Checkbox value="Dance" checked={checked.indexOf('Dance') !== -1} onChange={HandleChange} name="Hobby" />
        }
        label="Dance"
      />
      <FormControlLabel
        control={
          <Checkbox value="Sing" checked={checked.indexOf('Sing') !== -1} onChange={HandleChange} name="Hobby" />
        }
        label="Sing"
      />
    </FormGroup>
    {/* <FormHelperText>Be careful</FormHelperText> */}
  </FormControl>
  );
}