const initialState = "";

const userReducer = (state=initialState,action) => {
    
    switch(action.type){
        case "ADD_USER":
            state = [...state,action.payload]
            return state;

        case "EDIT_USER":
            const data = [...state]
            const editState = data.map(element=>element.id ===action.payload)
            state = editState;
            return state;

        case "DELETE_USER":
            const data1 = [...state]
            const filterId = data1.filter(element=> element.id !== action.payload)
            state = filterId;
            return state;
    default:
        return state;
}
}
export default userReducer;