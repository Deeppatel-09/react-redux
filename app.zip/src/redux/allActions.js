export const addUser = (data)=>{
    return {
        type: "ADD_USER",
        payload: data
    }
}

export const editUser = (id)=>{
    return {
        type: "EDIT_USER",
        payload: id
    }
}

export const deleteUser = (id)=>{
    return {
        type: "DELETE_USER",
        payload: id
    }
}