import { legacy_createStore as createStore } from 'redux'
import userReducer from './reducers/userReducer'
import {composeWithDevTools} from "redux-devtools-extension"
// import {combineReducers} from "redux"

// const mainReducers = combineReducers({
//     userReducer
// })

// const commonData= {FirstName: "",LastName: "",Email : "", Hobby: [], Gender:"", BloodGroup: "",Contact:"",DOB:""}

// const store = createStore(mainReducers,commonData,composeWithDevTools());

const store = createStore(userReducer,composeWithDevTools())

export default store;